@extends('layouts.app')

@role('student')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default">
                    <div class="panel-heading">Student</div>

                    <div class="panel-body">
                        <span style="color: #595; font-weight: bold;">OK!</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@endrole
