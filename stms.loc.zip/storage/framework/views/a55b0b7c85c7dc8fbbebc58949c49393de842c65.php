<?php if (\Entrust::hasRole('admin')) : ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1><i class="fa fa-users" aria-hidden="true"></i> Users Editing</h1>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.user.new')); ?>" class="btn btn-success btn-block btn-h1-spacing">Create New</a>
            </div>
            <div class="col-md-12">
                <hr>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Surname</th>
                                    <th>Patronymic</th>
                                    <th>E-mail</th>
                                    <th>Role</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->surname); ?></td>
                                        <td><?php echo e($user->patronymic); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->roles()->pluck('name')[0]); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                               class="btn btn-primary">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <?php echo $users->links(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; // Entrust::hasRole ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>