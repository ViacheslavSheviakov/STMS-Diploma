<?php if (\Entrust::hasRole('admin')) : ?>
<?php $__env->startSection('styles'); ?>
    <?php echo Html::style('css/parsley.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="well">
                    <div class="row">
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('admin.groups.show')); ?>" class="btn btn-default btn-block"><i class="fa fa-angle-left"></i> Back</a>
                        </div>
                        <div class="col-sm-6">
                            <?php echo Form::open(['route' => ['admin.group.delete', $group->id], 'method' => 'DELETE']); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-block']); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php echo Form::model($group, ['route' => ['admin.group.update', $group->id], 'method' => 'POST', 'data-parsley-validate' => '']); ?>


                        <?php echo e(Form::label('short_title', 'Short Title:')); ?>

                        <?php echo e(Form::text('short_title', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>


                        <?php echo e(Form::label('full_title', 'Full Title:')); ?>

                        <?php echo e(Form::text('full_title', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        <hr>
                        <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>

<?php $__env->stopSection(); ?>
<?php endif; // Entrust::hasRole ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>