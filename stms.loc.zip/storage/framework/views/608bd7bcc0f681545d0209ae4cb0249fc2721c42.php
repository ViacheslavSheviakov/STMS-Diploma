<?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
        <strong>Success:</strong> <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <strong>Error:</strong> <?php echo e(Session::get('error')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('info')): ?>
    <div class="alert alert-info" role="alert">
        <strong>Info:</strong> <?php echo e(Session::get('info')); ?>

    </div>
<?php endif; ?>