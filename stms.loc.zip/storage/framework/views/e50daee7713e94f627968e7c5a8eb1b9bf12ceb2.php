<?php if (\Entrust::hasRole('admin')) : ?>
<?php $__env->startSection('styles'); ?>
    <?php echo Html::style('css/parsley.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <a href="<?php echo e(route('admin.users.show')); ?>" class="btn btn-default"><i class="fa fa-arrow-left" aria-hidden="true"></i> Groups Editing</a>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">New Group</div>

                    <div class="panel-body">
                        <?php echo Form::open(['route' => 'admin.group.save', 'data-parsley-validate' => '']); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('short-title', 'Short Title:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::text('short-title', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('full-title', 'Full Title:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::text('full-title', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        </div>
                        <?php echo Form::submit('Create', ['class' => 'btn btn-success form-spacing-top']);; ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>

<?php $__env->stopSection(); ?>
<?php endif; // Entrust::hasRole ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>