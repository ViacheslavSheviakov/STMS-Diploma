<?php if (\Entrust::hasRole('admin')) : ?>
<?php $__env->startSection('styles'); ?>
    <?php echo Html::style('css/parsley.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <a href="<?php echo e(route('admin.users.show')); ?>" class="btn btn-default"><i class="fa fa-arrow-left" aria-hidden="true"></i> Users Editing</a>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">New User</div>

                    <div class="panel-body">
                        <?php echo Form::open(['route' => 'admin.user.save', 'data-parsley-validate' => '']); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('u-name', 'Name:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::text('u-name', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('u-surname', 'Surname:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::text('u-surname', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('u-patronymic', 'Patronymic:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::text('u-patronymic', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('u-email', 'E-mail:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::email('u-email', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('u-group', 'Group:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::select('u-group', collect([null => '-'])->merge($groups->pluck('short_title', 'short_title' )), '', ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('u-type', 'Type:', ['class' => 'control-label'])); ?>

                            <?php echo e(Form::select('u-type', $roles->pluck('name', 'id'), '', ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        </div>
                        <?php echo Form::submit('Create', ['class' => 'btn btn-success form-spacing-top']);; ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>

<?php $__env->stopSection(); ?>
<?php endif; // Entrust::hasRole ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>