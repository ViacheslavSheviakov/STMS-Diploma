<?php if (\Entrust::hasRole('admin')) : ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1><i class="fa fa-users" aria-hidden="true"></i> Groups Editing</h1>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.group.new')); ?>" class="btn btn-success btn-block btn-h1-spacing"><i class="fa fa-plus-square"></i> Create New</a>
            </div>
            <div class="col-md-12">
                <hr>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Short Title</th>
                                    <th>Full Title</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($group->id); ?></td>
                                        <td><?php echo e($group->short_title); ?></td>
                                        <td><?php echo e($group->full_title); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.group.edit', $group->id)); ?>"
                                               class="btn btn-primary"><i class="fa fa-edit"></i> Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <?php echo $groups->links(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; // Entrust::hasRole ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>