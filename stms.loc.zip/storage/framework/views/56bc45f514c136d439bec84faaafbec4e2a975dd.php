<?php if (\Entrust::hasRole('admin')) : ?>
<?php $__env->startSection('styles'); ?>
    <?php echo Html::style('css/parsley.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="well">
                    <a href="<?php echo e(route('admin.users.show')); ?>" class="btn btn-default"><i class="fa fa-angle-left"></i> Back</a>
                    <hr>
                    <table class="table table-bordered">
                        <tr>
                            <th>ID:</th>
                            <td><?php echo e($user->id); ?></td>
                        </tr>
                        <tr>
                            <th>Created At:</th>
                            <td><?php echo e(date('d.m.Y H:i', strtotime($user->created_at))); ?></td>
                        </tr>
                        <tr>
                            <th>Last Update:</th>
                            <td><?php echo e(date('d.m.Y H:i', strtotime($user->updated_at))); ?></td>
                        </tr>
                    </table>
                    <hr>
                    <div class="row">
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('admin.user.pass.restore', $user->id)); ?>" class="btn btn-primary btn-block">Restore PSWD</a>
                        </div>
                        <div class="col-sm-6">
                            <?php echo Form::open(['route' => ['admin.user.delete', $user->id], 'method' => 'DELETE']); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-block']); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php echo Form::model($user, ['route' => ['admin.user.update', $user->id], 'method' => 'POST', 'data-parsley-validate' => '']); ?>


                        <?php echo e(Form::label('name', 'Name:')); ?>

                        <?php echo e(Form::text('name', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>


                        <?php echo e(Form::label('surname', 'Surname:')); ?>

                        <?php echo e(Form::text('surname', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>


                        <?php echo e(Form::label('patronymic', 'Patronymic:')); ?>

                        <?php echo e(Form::text('patronymic', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>


                        <?php echo e(Form::label('email', 'E-mail:')); ?>

                        <?php echo e(Form::email('email', null, ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>


                        <?php echo e(Form::label('a-roles', 'Role:')); ?>

                        <?php echo e(Form::select('a-roles', $roles->pluck('name', 'id'), '' , ['class' => 'form-control', 'data-parsley-required' => 'true'])); ?>

                        <hr>
                        <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>

<?php $__env->stopSection(); ?>
<?php endif; // Entrust::hasRole ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>